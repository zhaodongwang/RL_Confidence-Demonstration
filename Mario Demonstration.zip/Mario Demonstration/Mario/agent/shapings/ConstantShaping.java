/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package agent.shapings;

import agent.state.StateAction;

/**
 *
 * @author timbrys
 */
public class ConstantShaping extends PotentialBasedShaping{

    protected double constant;
    
    public ConstantShaping(double scaling, double gamma, double constant){
        super(scaling, gamma);
        this.constant = constant;
    }
    
    @Override
    protected double actualPotential(StateAction sa) {
        return constant;
    }
    
}
